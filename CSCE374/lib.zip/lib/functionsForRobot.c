//the include statements
#include <avr/io.h>
#include <avr/interrupt.h>
#include "functionsForRobot.h"
#include <stdlib.h>
#include <stdio.h>

//used by the delay function
volatile uint16_t timerCount = 0;
volatile uint8_t timerRunning = 0;

void setupSerialPort(void) 
{
	// Set the transmission speed to 57600 baud, which is what the Create expects,
	// unless we tell it otherwise.
	UBRR0 = 19;
	// Enable both transmit and receive.
	UCSR0B = 0x18;
	// Set 8-bit data.
	UCSR0C = 0x06;
}

// Transmit one byte to the robot.
// Wait for the buffer to be empty.
void byteTx(uint8_t value) 
{
	while(!(UCSR0A & 0x20)) 
	{
		// Do nothing.
	}
	// Send the byte.
	UDR0 = value;
}

// Receive one byte from the robot.
// Call setupSerialPort() first.
// Wait for a byte to arrive in the receive buffer.
uint8_t byteRx(void) 
{
	while(!(UCSR0A & 0x80)) ;
	// Return that byte.
	return UDR0;
}

//the setup for this program includes the set up for all command module LEDs 
//and the timer, serial port, and turn the robot to full mode
void setup(void)
{
	//disable interrupts needed to make the timer work
	cli();

	void setupCommandLED(void);
	setupTimer();
	setupSerialPort();
	byteTx(opOpenInterface); // Start the open interface.
	byteTx(opFullMode); // Switch to full Mode

	//enabling interrupts needed to make the timer work
	sei();
	
	beepSetup();
	happySoundSetup();
	
	//gives the robot time to set up
	delayMs(1000);
	beep();
}

//which serial port should byteTx and byteRx talk to?
//use serialCreate to talk to the robot
//use serialUSB to talk to the computer
void setSerialDestination(uint8_t destination)
{
	//Ensure any pending bytes have been sent. Without this, the last byte sent
	//before calling this might seem to disappear.
	delayMs(10);
	
	//Configure the port.
	if(destination == serialCreate)
	{
		PORTB &= ~0x10;
	}
	
	else
	{
		PORTB |= 0x10;
	}
	
	//Wait a bit to let things get back to normal. According to the docs, this
	//should be at least 10 times the amount of time needed to send one byte.
	//This is less than 1 millisecond. We are using a much longer delay to be
	//super extra sure.
	delayMs(10);
}

//Set the fifth bit of the direction register for port D to 1.
//This sets pin 5 of port D, which controls the right LED, to output mode.
//This repeats for the left LED but instead of the fifth bit it is the sixth bit
//Do this once, at the start of the program, before calling commandLED.
void setupCommandLED(void) 
{
	DDRD |= (rightLED);
	DDRD |= (leftLED);
}

//this controls the LEDs on the command module first input controls which LED
//leftLED for the left LED and rightLED for the rightLED 
//and the second controls on/off on for on and off for off
void commandLED(int LED, int onOff)
{
	if(onOff)
	{
		PORTD &= ~(LED);
	}
	
	else
	{
		PORTD |= (LED);
	}
}

/*
	all inputs are uint_8t the first is the LED you want turned on
	
	to turn on the play LED the first input should be 2
	to turn on the advance LED the first input should be 8
	to turn on both 10.
	
	the last two inputs control the power LED the
	to make the power LED a color the second input
	should be 0 for green and 255 for red or any number in-between for a combination.
	
	the third input is the intensity from 0 to 255 with 0 being off
*/
void robotLED(uint8_t LED, uint8_t powerColor, uint8_t powerIntensity)
{
	byteTx(opRobotLED); //tells the robot we want to use the LEDs
	byteTx(LED); //the LED bits advance is 8, play is 2, both is 10, off is 0
	byteTx(powerColor); // the Power LED Color
	byteTx(powerIntensity); // the Power LED Intensity
}

//the set up for the timer
void setupTimer(void)
{
	// Set up the timer 1 interrupt to be called every 1ms.
	// It�s probably best to treat this as a black box.
	// Basic idea: Except for the 71, these are special codes, for which details
	// appear in the ATMega168 data sheet. The 71 is a computed value, based on
	// the processor speed and the amount of "scaling" of the timer, that gives
	// us the 1ms time interval.
	TCCR1A = 0x00;
	TCCR1B = 0x0C;
	OCR1A = 71;
	TIMSK1 = 0x02;
}

// Delay for the given number of milliseconds.
// Call setupTimer() before this.
void delayMs(uint16_t timeMs) 
{
	timerCount = timeMs;
	timerRunning = 1;
	while(timerRunning) 
	{
		// do nothing
	}
}

// Interrupt handler called every 1ms.
// Decrement the counter variable, to allow delayMs to keep time.
SIGNAL(SIG_OUTPUT_COMPARE1A) 
{
	if(timerRunning) 
	{
		if(timerCount != 0) 
		{
			timerCount--;
		}
		
		else 
		{
			timerRunning = 0;
		}
	}
}

//sends an opcode and a 16 bit number to the robot
void twoByteTx(int16_t byteToSend, int opCodeToSent)
{
	//vars used
	uint8_t hiByte = 0;
	uint8_t lowByte = 0;
	
	//shift the value right by 8 to get the high byte we need to send
	hiByte = (byteToSend >> 8);
	
	//and with 255 which is 11111111 in binary to remove the high bits
	lowByte = (byteToSend & maskLowByte);
	
	//sending the bytes to the robot
	byteTx(opCodeToSent);
	byteTx(hiByte);
	byteTx(lowByte);
}

//drives individual wheels at a certain velocity
void driveWheels(int16_t rightWheelmms, int16_t leftWheelmms)
{
	uint8_t rightHi;
	uint8_t rightLo;
	uint8_t leftHi;
	uint8_t leftLo;
	
	//shift the value right by 8 to get the high byte we need to send
	rightHi = (rightWheelmms >> 8);
	leftHi = (leftWheelmms >> 8);
	
	//and with 255 which is 11111111 in binary to remove the high bits
	rightLo = (rightWheelmms & maskLowByte);
	leftLo = (leftWheelmms & maskLowByte);
	
	byteTx(opDriveDirect);  //drive direct opcode
	byteTx(rightHi);
	byteTx(rightLo);
	byteTx(leftHi);
	byteTx(leftLo);
}

//same as drive wheels but if the bump sensor is pressed it turns left in place
void driveWheelsBump(int16_t rightWheelmms, int16_t leftWheelmms)
{

	//if sensorValue is not 0 it means that some sensor is triped so we know to turn the robot left
	while(isBumpSensor())
	{
		driveWheels(defaultVelocity, -defaultVelocity);
	}
	
	//if the bumper is not pressed we go at the velocitys
	driveWheels(rightWheelmms,leftWheelmms);
}

//sets the wheels to the velocity but if any of the bumpers are pressed it stops
//returns 1 if it bumped into something 0 else
int driveWheelsBumpStop(int16_t rightWheelmms, int16_t leftWheelmms)
{
	//if isBumpSensor is not 0 it means that some bump sensor is triped so we know to stop the robot
	if(isBumpSensor())
	{
		stop();
		
		return 1;
	}
	
	else
	{
		//if the bumper is not pressed we go at the velocitys
		driveWheels(rightWheelmms,leftWheelmms);
		
		return 0;
	}
}



//rotate robot a specified angle
//positive angle is counterclockwise rotation otherwise bad stuff happens
void rotate(int16_t degrees)
{
	twoByteTx(degrees, opWaitAngle);
}

//rotate while rotate button is pressed on the remote, will not rotate if there is an unsafe condition such as one of the wheels not tuching the ground
//pass in a in for the direction 1 goes left and 0 goes right or use the defined values left or right
//pass in a velocity as the second argument for how fast to rotate
void rotateSafeRemote(int direction, int velocity)
{
	
	//if any of the wheels are droped wheelDropSensorAll() will return somthing greater than 0
	//so we know not to turn
	if(wheelDropSensorAll() == 0)
	{	
		if(direction == turnLeft)
		{
			driveWheels(velocity, -velocity);
		}
		
		if(direction == turnRight)
		{
			driveWheels(-velocity, velocity);
		}
	}
	
	else
	{
		driveWheels(off,off);
	}
}

//drives fwoard while the fwoard button on the remote is pressed, also will not drive if there is a unsafe condition such as running into somthing or a cliff
//pass in a velocity for how fast to go
void driveSafeRemote(int velocity)
{
	//the var we will store the values of the sensors 
	int sensorValue = 0;
	
	//since these all act as bools if we add then and get more than 0 we have a sensor triggered and know not to move
	sensorValue += isBumpSensor();
	sensorValue += wheelDropSensorAll();
	sensorValue += sensorValuesThreshold(packetCliffLeftSignal, cliffSensorThreshold);
	sensorValue += sensorValuesThreshold(packetCliffRightSignal, cliffSensorThreshold);
	sensorValue += sensorValuesThreshold(packetCliffFrountLeftSignal, cliffSensorThreshold);
	sensorValue += sensorValuesThreshold(packetCliffFrountRightSignal, cliffSensorThreshold);
	
	//if sensorValue is not 0 it means that some sensor is triped so we know to stop the robot
	if(sensorValue == 0)
	{
		driveWheels(velocity, velocity);
	}
	
	else
	{
		driveWheels(off,off);
	}
}

//same as driveSafeRemote, but in an arc instead of a straight line
void arcSafeRemote(int direction, int velocity)
{
	//the var we will store the values of the sensors 
	int sensorValue = 0;
	
	//since these all act as bools if we add then and get more than 0 we have a sensor triggered and know not to move
	sensorValue += isBumpSensor();
	sensorValue += wheelDropSensorAll();
	sensorValue += sensorValuesThreshold(packetCliffLeftSignal, cliffSensorThreshold);
	sensorValue += sensorValuesThreshold(packetCliffRightSignal, cliffSensorThreshold);
	sensorValue += sensorValuesThreshold(packetCliffFrountLeftSignal, cliffSensorThreshold);
	sensorValue += sensorValuesThreshold(packetCliffFrountRightSignal, cliffSensorThreshold);
	
	//if sensorValue is not 0 it means that some sensor is triped so we know to stop the robot
	if(sensorValue == 0)
	{
		//the if statement that controles if it turns right
		if(direction == turnLeft)
		{
			driveWheels(velocity, velocity * arcSpeed);
		}
		
		//the if statement that controles if it turns right
		if(direction == turnRight)
		{
			driveWheels(velocity * arcSpeed, velocity);
		}
	}
	
	else
	{
		driveWheels(off,off);
	}
}

//drive robot specified distance
void travelDistance(int16_t distance)
{
	twoByteTx(distance, opWaitDistance);
}

//sends the command to get the sensor packed requested
void readSensors(int SensorPacket)
{
	//Opcode for "Read sensors"
	byteTx(opReadSensors);
	byteTx(SensorPacket); 
}

//returns a single byte sensor value
int readSensorsSingle(int SensorPacket)
{
	readSensors(SensorPacket);
	return byteRx();
}

//returns 0 for none, 1 for play, 2 for advance, and 3 for both
int buttons(void)
{
	//puts the packit into a var so we can get the information we want
	int buttons = readSensorsSingle(packetButtons);
	
	//if both buttons are pressed
	if((buttons & (1 << 0)) && (buttons & (1 << 2)))
	{
		return buttonBoth;
	}
	
	//if play button is presses
	if(buttons & (1 << 0))
	{
		return buttonPlay;
	}
	
	//if advance button is pressed
	if(buttons & (1 << 2))
	{
		return buttonAdvance;
	}
	
	//if none of the above return 0 since no buttons are pressed
	return buttonNone;
}

//takes in two uint8_t left and right these need to be declaired before you call this
//function and will set the passed in ints to the values of 1 if the bump sensor is pressed
void bumpSensors(uint8_t* leftBumper, uint8_t* rightBumper)
{
	readSensors(packetBumpAndWheelDrop);
	
	//stores the Bump and wheel drop packet
	uint8_t BumpAndWheelDrop = byteRx();

	//assigns a value of 1 if the button is pressed, or 0 otherwise
	*leftBumper = (BumpAndWheelDrop & maskLeftBumper) != 0;
	*rightBumper = (BumpAndWheelDrop & maskRightBumper) !=  0;
}

//returns 0 if none on the bump sensors are triggered else how many but not which
uint8_t isBumpSensor(void)
{
	uint8_t leftBumper = 0;
	uint8_t rightBumper = 0;
	
	bumpSensors(&leftBumper, &rightBumper);
	
	//if the addition of left and right bumper is not 0 then one of the bumpers is pressed
	return (leftBumper + rightBumper);
	
}

//takes in three uint8_t left, right, and caster, these need to be declaired before you call this
//function, and will set the passed in ints to the values of 1 if the wheel is dropped
void wheelDropSensors(uint8_t* leftWheel, uint8_t* rightWheel, uint8_t* casterWheel)
{
	readSensors(packetBumpAndWheelDrop);
	
	//stores the Bump and wheel drop packet
	uint8_t BumpAndWheelDrop = byteRx();

	//assigns a value of 1 if the button is pressed, or 0 otherwise
	*leftWheel = (BumpAndWheelDrop & maskWheelDropLeft) != 0;
	*rightWheel = (BumpAndWheelDrop & maskWheelDropRight) !=  0;
	*casterWheel = (BumpAndWheelDrop & maskWheelDropCaster) !=  0;
}

//returns 0 if no wheels are droped else the amout of wheels droped but not which are droped
uint8_t wheelDropSensorAll(void)
{
	//the values of the wheel drop sensors
	uint8_t leftWheel = 0;
	uint8_t rightWheel = 0;
	uint8_t casterWheel = 0;
	
	//gets teh values of the wheel drop sensors
	wheelDropSensors(&leftWheel, &rightWheel, &casterWheel);
	
	//the addition of the values of the wheel drop should be 0 if no wheels are droped
	return (leftWheel + rightWheel + casterWheel);
}


//returns 1 if there is a wall/cliff, 0 if there is not. 
//We need to pass in the sensor (wall/cliff) packets, defined in the header file
uint8_t wallCliffSensorOnOff(int sensorPacket)
{
	readSensors(sensorPacket);
	return byteRx();
}

//returns the values of the requested sensor battery, wall, or cliff when the sensor packet is passed in
//only works on packeds that are unsigned
uint16_t sensorValues(int sensorPacket)
{
	readSensors(sensorPacket);
	uint16_t high = byteRx();
	uint16_t low = byteRx();
	uint16_t returnValue = 0;

	//shifting the high byte left 8 so we can or it with the low byte to make the return value
	high = (high << 8);
	returnValue = (high | low);
	
	return returnValue;
}

//returns 0 if the sensor Values are under the threshold value
int sensorValuesThreshold(int sensorPacket, int threshold)
{
	if (sensorValues(sensorPacket) > threshold)
	{
		return 0;
	}
	
	else
	{
		return 1;
	}
}

//makes a square in the counter-clockwise direction
void makeSquareCCW(int16_t velocity, int16_t length)
{
	for(int i = 0; i < 4; i +=1)
	{
		delayMs(500);
		driveWheels(velocity, velocity);
		travelDistance(length);
		driveWheels(0,0);
		delayMs(500);
		driveWheels((velocity/2), -(velocity/2));
		rotate(90);
		driveWheels(off, off);
	}
}

//makes a square in the clockwise direction
void makeSquareCW(int16_t velocity, int16_t length)
{
	for(int i = 0; i < 4; i +=1)
	{
		delayMs(500);
		driveWheels(velocity, velocity);
		travelDistance(length);
		driveWheels(0,0);
		delayMs(500);
		driveWheels(-(velocity/2), (velocity/2));
		rotate(-90);
		driveWheels(off, off);
	}
}

//spins in circles for the set time
void donuts(int16_t velocity, int16_t duration)
{	
	delayMs(1000);
	driveWheels(velocity, -velocity);
	delayMs(duration);
	driveWheels(off, off);
}

//prints strings to console
//need to switch the serial output to USB
//need to pass in an array of characters
void printString(char string[])
{
	//used as a bool
	int end = 1;

	//the current position of the array
	int position = 0;

	//we use a while loop since we dont know how long the array is going to be
	while(end == 1)
	{
		//when we get to the end of the array we set end to 0 
		//which will break out of the while loop
		if(string[position] == '\0')
		{
			end = 0;
		}
		
		//prints the current char of the array and increments the array
		else
		{
			byteTx(string[position]);
			position += 1;
		}
	}

}

//prints the value of an unsigned 16 bit int to console
//need to switch the serial output to USB before using this function
void printUint16_t(uint16_t value)
{
	//the string we will print
	//size is set to 100 since this is more than we should need
	char intValue[100];

	//switching from an unsigned int to a string
	snprintf(intValue, 100, "%u", value);
	printString(intValue);
}

//return value of IR Packet
uint8_t readIRPackets(void)
{
	readSensors(packetIR);
	return byteRx();
}

//translates the remote signals to action safely 
void roombaRemote(void)
{
	//if the remote is telling us to go fword we make sure it is same to do so
	if (readIRPackets() == IRforward)
	{
		driveSafeRemote(defaultVelocity);
	}
	
	//if the remote is telling us to turn we make sure it is safe to do so
	else if (readIRPackets() == IRright)
	{
		rotateSafeRemote(turnRight, defaultTurnVelocity);
	}
	
	//if the remote is telling us to turn we make sure it is safe to do so
	else if (readIRPackets() == IRleft)
	{
		rotateSafeRemote(turnLeft, defaultTurnVelocity);
	}
	
	//currently makes the robot go backwards but this is not reccomended 
	//since there are only cliff sensors on the front of the robot
	else if (readIRPackets() == IRlargeClean)
	{
		driveWheels(-500, -500);
	}
	
	//makes the robot drive forward regardless of safety sensors
	else if (readIRPackets() == IRspot)
	{
		driveWheels(500, 500);
	}
	
	//make the robot drive in a left arc
	else if (readIRPackets() == IRarcForwardLeft)
	{
		arcSafeRemote(turnLeft, defaultVelocity);
	}
	
	//make the robot drive in a right arc
	else if (readIRPackets() == IRarcForwardRight)
	{
		arcSafeRemote(turnRight, defaultVelocity);
	}
		
	//makes the robot beep when the pause button (it's red) is pushed
	else if (readIRPackets() == IRpause)
	{
		beep();
	}
	
	//make the robot do donuts when max button is pressed
	else if (readIRPackets() == IRmax)
	{
		donuts(500, 5000);
	}
}

//plays the song number passed in
void playSound(int songNumber)
{
	byteTx(141);	//play song opcode
	byteTx(songNumber);		//song number
}

//sets up the beep
void beepSetup(void)
{
	//storing song of one note.  deal with the magic numbers
	byteTx(140);	//store song opcode
	byteTx(0);		//song number
	byteTx(1);		//song length
	byteTx(77);		//note
	byteTx(16);		//note duration
}

//makes the robot beep
void beep(void)
{
	playSound(0);
}

void happySoundSetup(void)
{
	//storing song of one note.  deal with the magic numbers
	byteTx(140);	//store song opcode
	byteTx(1);		//song number
	byteTx(3);		//song length
	byteTx(71);		//note1
	byteTx(16);		//note1 duration
	byteTx(72);		//note2
	byteTx(16);		//note2 duration
	byteTx(76);		//note3
	byteTx(40);		//note3 duration
}

//make the robot play a happy sound
void happySound(void)
{
	playSound(1);
}

//finds a wall by driving forwards till it hits one or the wall sensor is >= setPoint
void findWall(int setPoint)
{
	while(isBumpSensor() == 0 && sensorValues(packetWallSignal) < setPoint)
	{
		//for convenience when we pick the robot up it stops driving and the program does nothing
		pickUpStop();
		
		driveWheelsBump(defaultVelocity, defaultVelocity);
		robotLED(robotAdvanceLED, robotPowerGreen, robotPowerOn);
	}
}

//when we pick the robot up it stops driving and the program goes into
//a loop until the wheels return to normal
//if triggered the LED's will be power red and the play and advance off
void pickUpStop()
{
	//if any of the wheels are dropped we 
	while(wheelDropSensorAll())
	{
		//set the power LED to red and the rest off
		robotLED(off, robotPowerRed, robotPowerOn);
		
		//stop all movement
		stop();
	}
}

//stop all movement
void stop()
{
	//stop all movement
	driveWheels(off, off);
}

//returns 1 if the robot is docked 0 else
int isDocked()
{
	uint8_t chargeSources = readSensorsSingle(packetChargingSources);
	if ((chargeSources << 1) != 0)
	{
		return 1;
	}
	
	else
	{
		return 0;
	}
	
}

//jiggles the robot when on the dock in order to get it to make contact with the docks power source
// returns 0 if unsuccessful or 1 if docking was successful
int jiggleDock(void)
{

	for (int i=0; i < 6; i++)
	{
		if (isDocked() == 1)
		{
			stop();
			return 1;
		}
		
		delayMs(300);

		if (isDocked() == 1)
		{
			stop();
			return 1;
		}		
		
		if(isDocked() == 0)
		{
			driveWheels(-jiggleDockVelocity, -jiggleDockVelocity);
			delayMs(225);
			stop();
		}
	}
	
	driveWheels (-jiggleDockVelocity*5, -jiggleDockVelocity*5);
	delayMs(4000);
	stop();
	
	return 0;
}


//drive fowoards at max till we find the signal from the home
void findHomeSignal(void)
{
	while(readIRPackets() == IRnoSignal)
	{
		driveWheelsBumpStop(500, 500);
	}
}

//drives forwards till the IR signal changes
void forwardTillSignalChange(int dockSignal, int velocity)
{
	while(readIRPackets() == dockSignal)
	{
		driveWheelsBumpStop(velocity, velocity);
	}
}

//displays the docking fields using the LED's
//command LED's show which field left for green and right for red
//advance light comes on if force field is on
//goes into a infinate loop so don't call if you want to do something else
//if you press the play button it will exit the loop
void showDockingFields (void)
{
	while(1)
	{
		if(buttons() == buttonPlay)
		{
			break;
		}
		
		switch (readIRPackets())
		{
		case dockRedBuoy :
			//turn on the right LED so we know what part of the field we are in
			commandLED(leftLED, off);
			commandLED(rightLED, on);
			
			//sets the play on and advance off and the power LED to green
			//so we know were are not in the force field
			robotLED(robotPlayLED, robotPowerGreen, robotPowerOn);
			
			break;
			
		case dockGreenBuoy :
			//turn on the left LED so we know what part of the field we are in
			commandLED(leftLED, on);
			commandLED(rightLED, off);
			
			//sets the play on and advance off and the power LED to green
			//so we know were are not in the force field
			robotLED(robotPlayLED, robotPowerGreen, robotPowerOn);
			
			break;
			
		case dockRedGreenBuoy :
			//turn on both LED's so we know what part of the field we are in
			commandLED(bothLED, on);
			
			//sets the play on and advance off and the power LED to green
			//so we know were are not in the force field
			robotLED(robotPlayLED, robotPowerGreen, robotPowerOn);
			
			break;
			
		case dockRedForceField :
			//turn on the right LED so we know what part of the field we are in
			commandLED(leftLED, off);
			commandLED(rightLED, on);
			
			//sets the play on and advance on and the power LED to green
			//so we know that we are in the force field
			robotLED(robotPlayAdvanceLED, robotPowerGreen, robotPowerOn);
			
			break;
			
		case dockGreenForceField :
			//turn on the left LED so we know what part of the field we are in
			commandLED(leftLED, on);
			commandLED(rightLED, off);
			
			//sets the play on and advance on and the power LED to green
			//so we know that we are in the force field
			robotLED(robotPlayAdvanceLED, robotPowerGreen, robotPowerOn);
			
			break;
			
		case dockRedGreenForceField :
			//turn on both LED's so we know what part of the field we are in
			commandLED(bothLED, on);
			
			//sets the play on and advance on and the power LED to green
			//so we know that we are in the force field
			robotLED(robotPlayAdvanceLED, robotPowerGreen, robotPowerOn);
			
			break;
			
		default :
			//turn on both LED's so we know what part of the field we are in
			commandLED(bothLED, off);
			
			//sets the play off and advance off and the power LED to green
			//so we know were are not in the force field
			robotLED(off, robotPowerGreen, robotPowerOn);
			
			break;
		}
	}
}
