#ifndef functionsForRobot_H_
#define functionsForRobot_H_

//functions

//the setup for this program includes the set up for all command module LEDs and the timer
void setup(void);

//the one time setup to communicate with the robot
void setupSerialPort(void);


//sends a byte to the robot
void byteTx(uint8_t value);

//gets a byte from the robot
uint8_t byteRx(void);

//which serial port should byteTx and byteRx talk to?
//use serialCreate to talk to the robot
//use serialUSB to talk to the computer
void setSerialDestination(uint8_t destination);

/*
	all inputs are uint_8t the first is the LED you want turned on
	
	to turn on the play LED the first input should be 2
	to turn on the advance LED the first input should be 8
	to turn on both 10.
	
	the last two inputs control the power LED the
	to make the power LED a color the second input
	should be 0 for green and 255 for red or any number in-between for a combination.
	
	the third input is the intensity from 0 to 255 with 0 being off
*/
void robotLED(uint8_t LED, uint8_t powerColor, uint8_t powerIntensity);




//sets up the command module LEDs you only need to do this once in the beginning of the program if you want to use the command module LEDs
void setupCommandLED(void);

//this controls the LEDs on the command module first input controls which LED
//leftLED for the left LED and rightLED for the rightLED 
//and the second controls on/off on for on and off for off
void commandLED(int LED, int onOff);

//you need to call this in the beginning of the program if you want to use the delayMs function
void setupTimer(void);

//delays the execution of the program x milliseconds
void delayMs(uint16_t timeMs);

//drives individual wheels at a certain velocity
void driveWheels(int16_t rightWheelmms, int16_t leftWheelmms);

//same as drive wheels but if the bump sensor is pressed it turns left in place
void driveWheelsBump(int16_t rightWheelmms, int16_t leftWheelmms);

//sets the wheels to the velocity but if any of the bumpers are pressed it stops
//returns 1 if it bumped into something 0 else
int driveWheelsBumpStop(int16_t rightWheelmms, int16_t leftWheelmms);

//sends and opcode and a 16 bit number to the robot
void twoByteTx(int16_t byteToSend, int opCodeToSent);

//rotate robot a specified angle
void rotate(int16_t degrees);

//rotate while rotate button is pressed on the remote, will not rotate if there is an unsafe condition such as one of the wheels not tuching the ground
//pass in a in for the direction 1 goes left and 0 goes right or use the defined values left or right
//pass in a velocity as the second argument for how fast to rotate
void rotateSafeRemote(int direction, int velocity);

//drives fwoard while the fwoard button on the remote is pressed, also will not drive if there is a unsafe condition such as running into somthing or a cliff
//pass in a velocity for how fast to go
void driveSafeRemote(int velocity);

//same as driveSafeRemote, but in an arc instead of a straight line
void arcSafeRemote(int direction, int velocity);

//drive robot specified distance
void travelDistance(int16_t distance);

//sends the command to get the sensor packed requested and returns the value
void readSensors(int SensorPacket);

//returns a single byte sensor value
int readSensorsSingle(int SensorPacket);

//returns 1 for play, 2 for advance, and 0 for none
int buttons(void);

//takes in two uint8_t left and right these need to be declared before you call this
//function and will set the passed in ints to the values of 1 if the bump sensor is pressed
void bumpSensors(uint8_t* leftBumper, uint8_t* rightBumper);

//returns 0 if none on the bump sensors are triggered else how many but not which
uint8_t isBumpSensor(void);

//takes in three uint8_t left, right, and caster, these need to be declared before you call this
//function, and will set the passed in ints to the values of 1 if the wheel is dropped
void wheelDropSensors(uint8_t* leftWheel, uint8_t* rightWheel, uint8_t* casterWheel);

//returns 0 if no wheels are droped else the amout of wheels droped but not which are droped
uint8_t wheelDropSensorAll(void);

//returns 1 if there is a wall/cliff, 0 if there is not. 
//We need to pass in the sensor (wall/cliff) packets, defined in the header file
uint8_t wallCliffSensorOnOff(int sensorPacket);


//returns the values of the requested sensor battery, wall, and cliff 
//use only for sensors that return 2 bytes
uint16_t sensorValues(int sensorPacket);

//returns 0 if the sensor Values are over the threshold value
int sensorValuesThreshold(int sensorPacket, int threshold);

//drives the robot in a counter-clockwise square of a specific velocity and length
void makeSquareCCW(int16_t velocity, int16_t length);


//drives the robot in a clockwise square of a specific velocity and length
void makeSquareCW(int16_t velocity, int16_t length);

//spins in circles for the set time
void donuts(int16_t velocity, int16_t duration);

//prints strings to console
//need to switch the serial output to USB before using this function
//need to pass in an array of characters
void printString(char string[]);

//prints the value of an unsigned 16 bit int to console
//need to switch the serial output to USB before using this function
void printUint16_t(uint16_t value);	

//return value of IR Packet
uint8_t readIRPackets(void);

//translates the remote signals to action safely 
void roombaRemote(void);

//plays the song number passed in
void playSound(int songNumber);

//setup the beep
void beepSetup(void);

//make the robot beep
void beep(void);


//setup the happy sound
void happySoundSetup(void);

//make the robot play a happy sound
void happySound(void);

//finds a wall by driving forwards till it hits one or the wall sensor is >= setPoint
void findWall(int setPoint);

//when we pick the robot up it stops driving and the program goes into
//a loop until the wheels return to normal
//if triggered the LED's will be power red and the play and advance off
void pickUpStop(void);

//stop all movement
void stop(void);

//returns 1 if the robot is docked 0 else
int isDocked(void);

//jiggles the robot when on the dock in order to get it to make contact with the docks power source
int jiggleDock(void);

//drive fowoards at max till we find the signal from the home
void findHomeSignal(void);

//drives forwards till the IR signal changes
void forwardTillSignalChange(int dockSignal, int velocity);

//displays the docking fields using the LED's
//command LED's show which field left for green and right for red
//advance light comes on if force field is on
//goes into a infinate loop so don't call if you want to do something else
void showDockingFields (void);


//vars

//default velocity the slower this is the more time you have to check sensors
#define defaultVelocity 100
#define defaultTurnVelocity 100

#define jiggleDockVelocity 30

//used for commandLED function turns on the left or right LED of the command module
#define leftLED 64
#define rightLED 32
#define bothLED 96

//use for the robotLED function
#define robotPlayLED 2
#define robotAdvanceLED 8
#define robotPlayAdvanceLED 10
#define robotPowerGreen 0
#define robotPowerRed 255
#define robotPowerOn 255
#define robotPowerOff 0

//used in commandLED and robotLED function
#define off 0
#define on 1

//used for button presses
#define buttonNone 0
#define buttonPlay 1
#define buttonAdvance 2
#define buttonBoth 3

//used in rotateSafeRemote
#define turnLeft 1
#define turnRight 0

//the value the inside is slowed
#define arcSpeed 0.5

//bit masks
#define maskRightBumper (1 << 0)
#define maskLeftBumper (1 << 1)
#define maskLowByte 255
#define maskWheelDropLeft (1 << 3)
#define maskWheelDropRight (1 << 2)
#define maskWheelDropCaster (1 << 4)

//bit 5 is 1 and the rest are 0
#define pin5high 32

//bit 6 is 1 and the rest are 0
#define pin6high 64

//op codes
#define opOpenInterface 128
#define opFullMode 132
#define opRobotLED 139
#define opDriveDirect 145
#define opWaitAngle 157
#define opWaitDistance 156
#define opReadSensors 142

//sensor packet codes
#define packetBumpAndWheelDrop 7
#define packetWall 8
#define packetCliffLeft 9
#define packetCliffFrontLeft 10
#define packetCliffFront Right 11
#define packetCliffRight 12
#define packetVirtualWall 13
#define packetIR 17
#define packetButtons 18
#define packetDistance 19
#define packetChargingState 21
#define packetBatteryCharge 25
#define packetWallSignal 27
#define packetCliffLeftSignal 28
#define packetCliffFrountLeftSignal 29
#define packetCliffFrountRightSignal 30
#define packetCliffRightSignal 31
#define packetChargingSources 34

//IR Values
#define IRleft 129
#define IRforward 130
#define IRright 131
#define IRspot 132
#define IRmax 133
#define IRsmall 134
#define IRlargeClean 136
#define IRpause 137
#define IRpower 138
#define IRarcForwardLeft 139
#define IRarcForwardRight 140
#define IRdriveStop 141
#define IRnoSignal 255

//cliff sensor threshold if the value returned by the cliff sensors is greather than this value we have no cliff
//this is used to correct the cliff sensor values for diffrent floor materials
//the higher the number the less distance you need to be considered a cliff
#define cliffSensorThreshold 50

//used in set serial destination
#define serialCreate 1
#define serialUSB 2

//dock numbers
#define dockReserved 240
#define dockRedBuoy 248
#define dockGreenBuoy 244
#define dockForceField 242
#define dockRedGreenBuoy 252
#define dockRedForceField 250
#define dockGreenForceField 246
#define dockRedGreenForceField 254

#endif	/* functionsForRobot_H */